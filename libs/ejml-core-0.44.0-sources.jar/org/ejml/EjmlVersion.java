package org.ejml;

import javax.annotation.Generated;

/**
 * Automatically generated file containing build version information.
 */
@Generated("com.peterabeles.GVersion")
public final class EjmlVersion {
    public static final String MAVEN_GROUP = "org.ejml";
    public static final String MAVEN_NAME = "autocode";
    public static final String VERSION = "0.44.0";
    public static final int GIT_REVISION = 1102;
    public static final String GIT_SHA = "7d47450d8451ee081a77fe304d9984ceb27e6fa7";
    public static final String GIT_DATE = "2025-03-22T01:15:08Z";
    public static final String GIT_BRANCH = "HEAD";
    public static final String BUILD_DATE = "2025-03-22T01:19:24Z";
    public static final long BUILD_UNIX_TIME = 1742606364028L;
    public static final int DIRTY = 0;

    private EjmlVersion(){}
}
